package emailapp;

import com.sun.security.jgss.GSSUtil;

import java.util.Scanner;

public class emailUse {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first name:");
        String firstName = sc.next();
        System.out.println("Enter last name:");
        String lastName = sc.next();
        Email email = new Email(firstName,lastName);
        int choice = -1;
        do{
            System.out.println("\n******\nEnter your choice\n1. Show Info\n2. Change password \n3. Change mailbox capacity \n4.Set Alternate mail \n5.Exit");
            choice = sc.nextInt();
            switch (choice){
                case(1):
                    email.getInfo();
                    break;
                case(2):
                    email.set_password();
                    break;
                case(3):
                    email.setMailCapacity();
                    break;
                case(4):
                    email.alternateEmail();
                case (5):
                    System.out.println("Thank you for using application");
                    break;
                default:
                    System.out.println("Invalid choice!! \nEnter proper choice ");


            }
        }while (choice!=5);
        System.out.println(email.generateEmail());
    }
}
