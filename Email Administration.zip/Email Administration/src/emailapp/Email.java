package emailapp;
import java.util.*;
import java.io.*;


public class Email {
      public Scanner s = new Scanner(System.in);
      //setting variables
      // private access specifier is used so that no one usese this variables directily
      private String firstName;
      private String lastName;
      private String department;
      private String email;
      private String password;
      private int mailCapacity = 500;
      private String alternateEmail ;
      //Constructor to print firstName and LastName
      public Email(String firstName , String lastName ){
           this.firstName = firstName;
           this.lastName = lastName;
           //calling methods;
            this.department=this.setDepartment();
            this.password=this.generate_password(8);
            this.email = this.generateEmail();


            System.out.println("New Employee:-"+" "+this.firstName+this.lastName);


      }
      //Generate Email
      public String generateEmail(){
            return  this.firstName.toLowerCase()+"."+this.lastName.toLowerCase()+"@"+this.department.toLowerCase()+".company.com";
      }
      //Asking for department;
      private String setDepartment(){
            System.out.println("Department codes \n1 for sales \n2 for Development \n3 for");
            boolean flag = false;
            do{
                  System.out.println("Enter Department code :");
                  int choice = s.nextInt();
                  switch (choice){
                        case 1 :
                              return "Sales";
                        case 2 :
                              return "Development";
                        case 3 :
                              return "Accounting";
                        default:
                              System.out.println("Invalid choice please choose as per codes");
                  }
            }while(!flag);


            return " ";
      }
      //Generate password
      private String generate_password(int length){
            Random rand = new Random();
            String captailLetters = "QWERTYUIOPASDFGHJKLZXCVBNM";
            String smallLLetters = "qwertyuiopasdfghjklzxcvbnmm";
            String numbers = "7894561230";
            String symbols = "!@#$%^&*<>";
            String values = captailLetters+smallLLetters+numbers+symbols;
            String password = "";
            for(int i = 0 ; i<length ; i++){
                  password = password + values.charAt(rand.nextInt(values.length()));
            }
            return password+" ";
       }
       // change password method
      public void set_password(){
            boolean flag = false;
            do{
                  System.out.println("Do you want to change your password! (Y/N)");
                  char choice =  s.next().charAt(0);
                  if(choice=='Y' || choice == 'y'){
                        flag = true;
                        System.out.println("Enter current password");
                        String temp = s.next();
                        if(temp.equals(this.password)){
                              System.out.println("Enter new password: ");
                              this.password = s.next();
                              System.out.println("Password change succesfully");
                        }else {
                              System.out.println("Incorrect Password");
                        }
                  }else if(choice == 'N' || choice =='n'){
                        flag =true;
                        System.out.println("Password chnaged option cancelled");
                  }else {
                        System.out.println("Enter valid choice");
                  }

            }while(!flag);
      }
      // set mail box capacity method
      public  void setMailCapacity(){
            System.out.println("Current capacity = "+this.mailCapacity+"mb");
            System.out.println("Enter new mailbox capacity: ");
            this.mailCapacity = s.nextInt();
            System.out.println("Mailbox Capacity is succesfully changed");
      }
      // set alternate mail
      public void alternateEmail(){
            System.out.println("Enter new alternate mail: ");
            this.alternateEmail = s.next();
            System.out.println("Alternate email is set");
      }
      // dispay user information metod

      public void getInfo(){
            System.out.println("New"+this.firstName+this.lastName);
            System.out.println("Department: "+this.department);
            System.out.println("Email: "+this.email);
            System.out.println("Department: "+this.department);
            System.out.println("Password"+this.password);
            System.out.println("Mailbox Capacity"+this.mailCapacity);
            System.out.println("Alternate mail"+this.alternateEmail);

      }


}
